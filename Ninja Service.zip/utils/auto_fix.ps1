﻿$host.UI.RawUI.WindowTitle = "Авто-Фикс Zapret"

# Check Admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ОШИБКА] Запустите от имени администратора" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Dir Variables
$rootDir = Split-Path $PSScriptRoot -Parent
$binDir = Join-Path $rootDir "bin"
$utilsDir = Join-Path $rootDir "utils"

$ninjaService = Join-Path $rootDir "ninja_service.bat"
$logDir = Join-Path $binDir "$(Get-Date -Format 'yyyy-MM-dd HH-mm-ss').log"
$ipsetUpdateDir = Join-Path $utilsDir "ipset_update.ps1"
$hostsUpdateDir = Join-Path $utilsDir "hosts_update.ps1"

# Start Log
New-Item -ItemType Directory -Force -Path (Split-Path $logDir) | Out-Null
Start-Transcript -Path $logDir -Force | Out-Null

# Check Zapret
$service = Get-Service -Name "zapret" -ErrorAction SilentlyContinue
if (!$service) {
    Write-Host "[ОШИБКА] Служба zapret не найдена" -ForegroundColor Red
} else {
    if ($service.Status -ne "Running") {
        Write-Host "[ИНФО] Служба zapret не запущена. Выполняется запуск" -ForegroundColor Cyan
        Start-Service zapret
        Write-Host "[ОК] Служба zapret работает" -ForegroundColor Green
    }

    if ((Get-Service zapret).Status -eq "Running") {
        Write-Host "[ОК] Служба zapret работает" -ForegroundColor Green
    }
    else {
        Write-Host "[ОШИБКА] Не удалось запустить службу zapret" -ForegroundColor Red
    }
}

# Set Timestamps
if (-not (Get-NetTCPSetting -SettingName Internet).Timestamps) {
    Write-Host "[ИНФО] TCP timestamps не включены. Выполняется включение" -ForegroundColor Cyan
    Set-NetTCPSetting -SettingName Internet -Timestamps Enabled | Out-Null
    Write-Host "[ОК] TCP timestamps включены" -ForegroundColor Green
} else {
    Write-Host "[ОК] TCP timestamps включены" -ForegroundColor Green
}
Write-Host

# Update IPset
if (Test-Path $ipsetUpdateDir) {
    & $ipsetUpdateDir -SilentMode
    Write-Host "[ОК] IPset успешно обновлен" -ForegroundColor Green
} else {
    Write-Host "[ОШИБКА] Не удалось найти скрипт обновления IPset" -ForegroundColor Red
}

# Update IPset
if (Test-Path $hostsUpdateDir) {
    & $hostsUpdateDir -SilentMode
    Write-Host "[ОК] Hosts успешно обновлен" -ForegroundColor Green
} else {
    Write-Host "[ОШИБКА] Не удалось найти скрипт обновления hosts" -ForegroundColor Red
}
$host.UI.RawUI.WindowTitle = "Авто-Фикс Zapret"

# Restart Zapret
try {
    Restart-Service zapret -Force -ErrorAction SilentlyContinue
    Write-Host "[ОК] Zapret успешно перезапущен" -ForegroundColor Green
}
catch {
    Write-Host "[ОШИБКА] Неудалось перезапустить Zapret" -ForegroundColor Red
}

Write-Host
Write-Host "[ОК] Авто-Фикс успешно выполнен" -ForegroundColor Green
Write-Host "[ИНФО] Лог Авто-Фикса был сохранен по пути $logDir" -ForegroundColor Cyan
Write-Host "Нажмите любую кнопку для выхода..."

Stop-Transcript | Out-Null
[void][System.Console]::ReadKey($true)

Start-Process $ninjaService -NoNewWindow
exit