﻿$host.UI.RawUI.WindowTitle = "Авто-Запуск Zapret"

# Check Admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ОШИБКА] Запустите от имени администратора" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Dir Variables
$rootDir = Split-Path $PSScriptRoot -Parent
$preConfigsDir = Join-Path $rootDir "pre-configs"
$binDir = Join-Path $rootDir "bin"
$listsDir = Join-Path $rootDir "lists"

$ninjaService = Join-Path $rootDir "ninja_service.bat"
$gameFilterFile = Join-Path $rootDir "bin\game_filter.enabled"
$winwsService = Join-Path $rootDir "bin\winws.exe"

# Tatget Configs
$batFiles = Get-ChildItem $preConfigsDir -Filter "*.bat" |
            Sort-Object Name
Set-Location $preConfigsDir

if (-not $batFiles) {
    Write-Host "[ОШИБКА] Ненайдены general*.bat файлы" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Game Filter Status
if (Test-Path $gameFilterFile) {
    $gameFilter = "1024-65535"
} else {
    $gameFilter = "12"
}

# User Input
Write-Host "[ВВОД] Введите номер конфига (цифра)" -ForegroundColor Cyan
Write-Host ""

for ($i = 0; $i -lt $batFiles.Count; $i++) {
    Write-Host "$($i + 1). $($batFiles[$i].Name)"
}

Write-Host ""
Write-Host "[ВВОД] Ваш выбор [1-$i]: " -ForegroundColor Cyan -NoNewline
$batNumber = (Read-Host) -as [int]

# Check Input
if ($null -eq $batNumber -or
    $batNumber -gt $batFiles.Count -or
    $batNumber -eq 0) 
{
    Write-Host
    Write-Host "[ОШИБКА] Неверный выбор" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}
Clear-Host
Write-Host "[ИНФО] Добавление Zapret в Авто-Запуск может занять некоторое время. Пожалуйста, подождите" -ForegroundColor Cyan
Write-Host "[ИНФО] Добавляемый конфиг: $($batFiles[$batNumber - 1])" -ForegroundColor Cyan
Write-Host

# Parse Arguments
$selectedFile = $batFiles[$batNumber - 1].FullName
$fileName = $batFiles[$batNumber - 1].BaseName
$lines = Get-Content $selectedFile -Raw

$winwsPattern = 'winws.exe'
$pos = $lines.IndexOf($winwsPattern, [System.StringComparison]::OrdinalIgnoreCase)
$rawArgs = ""

if ($pos -ge 0) {
    $start = $pos + $winwsPattern.Length
    $rawArgs = $lines.Substring($start)
} else {
    Write-Host "[ОШИБКА] В выбранном .bat не найден запуск winws.exe" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."

    [void][System.Console]::ReadKey($true)
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Delete Bin
$rawArgs = $rawArgs.Substring(2)
$rawArgs = $rawArgs.Replace('exit /b 0', '')

$rawArgs = $rawArgs.Replace('^', '')
$rawArgs = $rawArgs.Replace('=', ' ')

$rawArgs = $rawArgs.Replace('sni ', 'sni=')
$rawArgs = $rawArgs -replace '\r?\n', ''

# Replace Variables
$rawArgs = $rawArgs.Replace('%GameFilter%', $gameFilter)
$rawArgs = $rawArgs.Replace('%BIN%', "$binDir\")
$rawArgs = $rawArgs.Replace('%LISTS%',"$listsDir\")

$finalArgs = $rawArgs.Trim()

# Set Timestamps
if (-not (Get-NetTCPSetting -SettingName Internet).Timestamps) {
    Set-NetTCPSetting -SettingName Internet -Timestamps Enabled | Out-Null
}

# Remove Zapret
try {
    Stop-Service -Name 'zapret' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'zapret' -ErrorAction SilentlyContinue

    Write-Host "[ОК] Сервис zapret успешно удален" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось удалить сервис Zapret" -ForegroundColor Red
}

# Remove Winws
try {
    Stop-Process -Name 'winws' -Force -ErrorAction SilentlyContinue
} catch {}

# WinDivert
try {
    Stop-Service -Name 'WinDivert' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'WinDivert' -ErrorAction SilentlyContinue
} catch {}

# WinDivert14
try {
    Stop-Service -Name 'WinDivert14' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'WinDivert14' -ErrorAction SilentlyContinue
} catch {}

# Create Service
$winwsDir = "`"$winwsService`" $finalArgs"
try {
    New-Service `
        -Name zapret `
        -BinaryPathName $winwsDir `
        -DisplayName 'zapret' `
        -StartupType Automatic | Out-Null

    Write-Host "[ОК] Сервис zapret успешно создан" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось создать сервис Zapret" -ForegroundColor Red
}

# Edit Service
try {
    Set-Service -Name 'zapret' -Description 'Ninja Service'
    Write-Host "[ОК] Конфигурация сервиса успешно обновлена" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось обновить конфигурацию сервиса" -ForegroundColor Red
}

# Start Service
try {
    Start-Service -Name zapret -ErrorAction Stop
    Write-Host "[ОК] Сервис успешно запущен" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось запустить сервис" -ForegroundColor Red
}

# Edit Regedit
try {
    New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\zapret' -Name 'zapret-discord-youtube' -Value $fileName -PropertyType String -Force | Out-Null
    Write-Host "[ОК] Regedit успешно обновлен" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось обновить Regedit" -ForegroundColor Red
}

Write-Host ""
Write-Host "[ОК] Сервис успешно установлен в Авто-Запуск" -ForegroundColor Green
Write-Host "Нажмите любую клавишу для выхода..."

[void][System.Console]::ReadKey($true)
Start-Process $ninjaService -NoNewWindow
exit