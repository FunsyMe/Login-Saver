﻿$host.UI.RawUI.WindowTitle = "Перезапустить Zapret"

# Check Admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ОШИБКА] Запустите от имени администратора" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)

    Start-Process $ninjaService -NoNewWindow
    exit
}

# Dir Variables
$rootDir = Split-Path $PSScriptRoot -Parent
$ninjaService = Join-Path $rootDir "ninja_service.bat"

# Restart Zapret
try {
    Restart-Service zapret -Force -ErrorAction SilentlyContinue
}
catch {
    Write-Host "[ОШИБКА] Неудалось перезапустить Zapret" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)

    Start-Process $ninjaService -NoNewWindow
    exit
}

Write-Host "[ОК] Zapret успешно перезапущен" -ForegroundColor Green
Write-Host "Нажмите любую клавишу для выхода..."
[void][System.Console]::ReadKey($true)

Start-Process $ninjaService -NoNewWindow
exit