﻿$host.UI.RawUI.WindowTitle = "Обновление Ninja Service"

# Dir Variables
$rootDir = Split-Path $PSScriptRoot -Parent
$ninjaService = Join-Path $rootDir "ninja_service.bat"
$versionFile = Join-Path $rootDir "bin\ninja_version.txt"

# Archive Variables
$zipDir = "$env:TEMP\Ninja.Service.zip"
$extractDir = "$env:TEMP\Ninja.Service"

# Check Admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())

if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ОШИБКА] Запустите от имени администратора" -ForegroundColor Red
    Write-Host "Нажмите любую кнопку для выхода..."
    [void][System.Console]::ReadKey($true)

    Start-Process $ninjaService -NoNewWindow
    exit
}

# Get Release
Write-Host "[ИНФО] Идет поиск обновлений Ninja Service" -ForegroundColor Cyan
$release = Invoke-RestMethod `
    -Uri "https://api.github.com/repos/FunsyMe/Ninja-Service/releases/latest" `
    -Headers @{ "Accept" = "application/vnd.github+json" }
$newVersion = $release.tag_name.Replace('v', '')

# Compare Verison
$oldVersion = Get-Content $versionFile | Select-Object -First 1

if ($newVersion -le $oldVersion) {
    Write-Host
    Write-Host "[ИНФО] Новых обновлений не найдено" -ForegroundColor Cyan
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}
Write-Host "[ИНФО] Найдено новое обновление Ninja Serivce v$newVersion" -ForegroundColor Cyan

# User Input
Write-Host "[ВВОД] Вы хотите обновить Ninja Service (Y/N): " -ForegroundColor Cyan -NoNewline
$continue = Read-Host

if ($continue.ToLower() -eq "n") {
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Zapret
try {
    Stop-Service -Name 'zapret' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'zapret' -ErrorAction SilentlyContinue

    Write-Host "[ОК] Сервис zapret успешно удален" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось удалить сервис Zapret" -ForegroundColor Red
}

# Winws
try {
    Stop-Process -Name 'winws' -Force -ErrorAction SilentlyContinue
    Write-Host "[ОК] Сервис winws успешно удален" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось удалить сервис winws" -ForegroundColor Red
}

# WinDivert
try {
    Stop-Service -Name 'WinDivert' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'WinDivert' -ErrorAction SilentlyContinue

    Write-Host "[ОК] Сервис WinDivert успешно удален" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось удалить сервис WinDivert" -ForegroundColor Red
}

# WinDivert14
try {
    Stop-Service -Name 'WinDivert14' -Force -ErrorAction SilentlyContinue
    Remove-Service -Name 'WinDivert14' -ErrorAction SilentlyContinue

    Write-Host "[ОК] Сервис WinDivert14 успешно удален" -ForegroundColor Green
} catch {
    Write-Host "[ОШИБКА] Не удалось удалить сервис WinDivert14" -ForegroundColor Red
}

# Download Archive
try {
    Invoke-WebRequest -Uri "https://github.com/FunsyMe/Ninja-Service/releases/download/v$newVersion/Ninja.Service.zip" -OutFile $zipDir
    Write-Host "[ОК] Ninja Service успешно скачался" -ForegroundColor Green
}
catch {
    Write-Host "[ОШИБКА] Не удалось скачать Ninja Service" -ForegroundColor Red
    Write-Host "Нажмите любую клавишу для выхода..."
    [void][System.Console]::ReadKey($true)
    
    Start-Process $ninjaService -NoNewWindow
    exit
}

# Unarchive
if (Test-Path $extractDir) {
    Remove-Item $extractDir -Recurse -Force
}
Expand-Archive -Path $zipDir -DestinationPath $extractDir

# Clear Folder
if (Test-Path $rootDir) {
    Get-ChildItem -Path $rootDir -Force |
        Where-Object { $_.Name -ne "zapret_update.ps1" } |
        Remove-Item -Recurse -Force | Out-Null
} else {
    New-Item -ItemType Directory -Path $rootDir | Out-Null
}

# Copy Files
Copy-Item -Path "$extractDir\*" -Destination $rootDir -Recurse -Force
Write-Host "[ОК] Ninja Service успешно обновлен" -ForegroundColor Green
Write-Host "Нажмите любую клавишу для выхода..."
[void][System.Console]::ReadKey($true)
    
Start-Process $ninjaService -NoNewWindow
exit